"""
seofrog/exporters/sheets/links_internos_redirect.py
Aba específica para Links Internos com Redirects - NOVO
"""

import pandas as pd
from .base_sheet import BaseSheet

class LinksInternosRedirectSheet(BaseSheet):
    """
    Sheet específica para links internos com redirects (padrão Screaming Frog)
    Gera aba "Internal" com colunas: Type, From, To, Anchor Text, Alt Text, Follow, Target, Rel, Status Code, Status
    """
    
    def get_sheet_name(self) -> str:
        return 'Internal'
    
    def create_sheet(self, df: pd.DataFrame, writer) -> None:
        """
        Cria aba Internal com links internos que fazem redirect (padrão Screaming Frog)
        Colunas: Type, From, To, Anchor Text, Alt Text, Follow, Target, Rel, Status Code, Status
        """
        try:
            redirect_issues = []
            
            # Debug: Log colunas disponíveis para verificar dados
            self.logger.debug(f"Colunas disponíveis para análise de redirects: {list(df.columns)}")
            
            # Processa dados de redirects específicos do LinksParser
            if 'internal_redirects_details' in df.columns:
                self.logger.debug("Encontrada coluna 'internal_redirects_details' - processando...")
                
                for _, row in df.iterrows():
                    redirects_data = row.get('internal_redirects_details', [])
                    if isinstance(redirects_data, list) and redirects_data:
                        self.logger.debug(f"Processando {len(redirects_data)} redirects de {row.get('url', 'URL_UNKNOWN')}")
                        
                        for redirect in redirects_data:
                            if isinstance(redirect, dict):
                                status_code = redirect.get('Código', '')
                                status_text = self._get_status_text(status_code)
                                anchor_text = redirect.get('Anchor', '').strip()
                                
                                # Debug do anchor text
                                if anchor_text:
                                    self.logger.debug(f"Anchor text encontrado: '{anchor_text}' para {redirect.get('From', '')} → {redirect.get('To (Final)', '')}")
                                
                                redirect_issues.append({
                                    'Type': 'Hyperlink',
                                    'From': redirect.get('From', ''),
                                    'To': redirect.get('To (Final)', redirect.get('To (Original)', '')),
                                    'Anchor Text': anchor_text,
                                    'Link Path': redirect.get('Link Path', self._generate_link_path()),
                                    'Alt Text': redirect.get('Alt Text', ''),
                                    'Follow': redirect.get('Follow', 'True'),
                                    'Target': redirect.get('Target', ''),
                                    'Rel': redirect.get('Rel', ''),
                                    'Status Code': status_code,
                                    'Status': status_text
                                })
            
            # Se não encontrou redirects específicos, analisa redirects básicos dos dados crawleados
            if not redirect_issues:
                self.logger.debug("Nenhum redirect encontrado em 'internal_redirects_details', analisando dados básicos...")
                
                for _, row in df.iterrows():
                    url = row.get('url', '')
                    final_url = row.get('final_url', '')
                    status_code = row.get('status_code', 200)
                    
                    # Detecta redirects (URL original != final)
                    if url != final_url and url and final_url:
                        status_text = self._get_status_text(status_code)
                        
                        # Tenta extrair anchor text de possíveis fontes
                        anchor_text = self._extract_anchor_text_from_row(row)
                        
                        redirect_issues.append({
                            'Type': 'Hyperlink',
                            'From': url,
                            'To': final_url,
                            'Anchor Text': anchor_text,
                            'Link Path': self._generate_link_path(),
                            'Alt Text': '',
                            'Follow': 'True',
                            'Target': '',
                            'Rel': '',
                            'Status Code': status_code,
                            'Status': status_text
                        })
            
            # Processa outros possíveis dados de links internos
            self._process_additional_link_data(df, redirect_issues)
            
            # Log final do que foi encontrado
            if redirect_issues:
                anchors_found = sum(1 for item in redirect_issues if item['Anchor Text'].strip())
                self.logger.info(f"Processados {len(redirect_issues)} redirects, {anchors_found} com anchor text")
            
            if redirect_issues:
                # Cria DataFrame com colunas no padrão Screaming Frog
                redirects_df = pd.DataFrame(redirect_issues)
                
                # Remove duplicatas baseado em From + To
                redirects_df = redirects_df.drop_duplicates(subset=['From', 'To'], keep='first')
                
                # Ordena por Status Code e depois por From
                redirects_df = redirects_df.sort_values(['Status Code', 'From'])
                
                # Define ordem das colunas (padrão Screaming Frog completo)
                column_order = [
                    'Type', 'From', 'To', 'Anchor Text', 'Link Path', 'Alt Text', 
                    'Follow', 'Target', 'Rel', 'Status Code', 'Status'
                ]
                
                # Garante que todas as colunas existem
                for col in column_order:
                    if col not in redirects_df.columns:
                        redirects_df[col] = ''
                
                # Reordena colunas
                redirects_df = redirects_df[column_order]
                
                # Exporta para Excel
                redirects_df.to_excel(writer, sheet_name=self.get_sheet_name(), index=False)
                self.logger.info(f"✅ {self.get_sheet_name()}: {len(redirects_df)} redirects encontrados")
                
            else:
                # Nenhum redirect encontrado - usando padrão Screaming Frog
                success_df = pd.DataFrame([
                    ['No redirects found', '', '', '', '', '', '', '', '', '', '']
                ], columns=[
                    'Type', 'From', 'To', 'Anchor Text', 'Link Path', 'Alt Text', 
                    'Follow', 'Target', 'Rel', 'Status Code', 'Status'
                ])
                success_df.to_excel(writer, sheet_name=self.get_sheet_name(), index=False)
                self.logger.info(f"✅ {self.get_sheet_name()}: Nenhum redirect encontrado")
                
        except Exception as e:
            self.logger.error(f"Erro criando aba de redirects: {e}")
            self._create_error_sheet(writer, f'Erro na análise de links internos: {str(e)}')
    
    
    def _get_status_text(self, status_code) -> str:
        """
        Converte código HTTP em texto descritivo (padrão Screaming Frog)
        """
        status_map = {
            200: 'OK',
            301: 'Moved Permanently',
            302: 'Found',
            303: 'See Other',
            307: 'Temporary Redirect',
            308: 'Permanent Redirect',
            400: 'Bad Request',
            401: 'Unauthorized',
            403: 'Forbidden',
            404: 'Not Found',
            410: 'Gone',
            500: 'Internal Server Error',
            502: 'Bad Gateway',
            503: 'Service Unavailable',
            504: 'Gateway Timeout'
        }
        
        if isinstance(status_code, (int, float)):
            return status_map.get(int(status_code), f'HTTP {int(status_code)}')
        elif isinstance(status_code, str) and status_code.isdigit():
            return status_map.get(int(status_code), f'HTTP {status_code}')
        else:
            return str(status_code) if status_code else 'Unknown'