"""
seofrog/exporters/sheets/links_internos_redirect.py
🔧 VERSÃO CORRIGIDA - Resolve erro "truth value of an empty array is ambiguous"
"""

import pandas as pd
import numpy as np
from urllib.parse import urlparse, urljoin
from .base_sheet import BaseSheet

class LinksInternosRedirectSheet(BaseSheet):
    """
    Sheet que detecta links internos apontando para URLs que redirecionam
    🔧 CORRIGIDO: Tratamento adequado de arrays vazios
    """
    
    def get_sheet_name(self) -> str:
        return 'Links Internos Redirect'
    
    def create_sheet(self, df: pd.DataFrame, writer) -> None:
        """
        🔧 CORRIGIDO: Cria aba de links internos com tratamento de arrays vazios
        """
        try:
            # 🔧 CORREÇÃO: Verificação segura de DataFrame vazio
            if len(df) == 0:
                self._create_success_sheet(writer, '✅ Nenhum dado disponível para análise de redirects!')
                return
            
            # 🎯 Detecta redirects usando método híbrido
            problem_links = self._detect_redirects_hybrid_method(df)
            
            # 🔧 CORREÇÃO: Verificação segura de lista vazia
            if len(problem_links) == 0:
                self._create_success_sheet(writer, '✅ Todos os links internos apontam diretamente para o destino final!')
                return
            
            # 🎯 FORMATO SCREAMING FROG: Ajusta estrutura de dados
            screaming_frog_data = []
            for link in problem_links:
                screaming_frog_data.append({
                    'Type': 'Hyperlink',
                    'From': str(link.get('pagina_origem', '')),
                    'To': str(link.get('url_linkada', '')),
                    'Status Code': str(link.get('codigo_redirect', '')),
                    'Redirect To': str(link.get('destino_final', '')),
                    'Anchor Text': str(link.get('anchor_text', ''))[:100],
                    'Redirect Type': str(link.get('tipo_problema', '')),
                    'Response Time': str(link.get('response_time', '')),
                    'Issue': self._format_issue_description(link),
                    'Priority': str(link.get('criticidade', 'BAIXO'))
                })
            
            # 🔧 CORREÇÃO: Verificação antes de criar DataFrame
            if len(screaming_frog_data) == 0:
                self._create_success_sheet(writer, '✅ Nenhum redirect problemático encontrado!')
                return
            
            # Cria DataFrame com formato SF
            issues_df = pd.DataFrame(screaming_frog_data)
            
            # 🎯 ORDENAÇÃO COMO SF: Por criticidade e depois alfabética
            priority_order = {'CRÍTICO': 1, 'ALTO': 2, 'MÉDIO': 3, 'BAIXO': 4}
            issues_df['_priority'] = issues_df['Priority'].map(priority_order).fillna(4)
            issues_df = issues_df.sort_values(['_priority', 'From', 'To']).drop('_priority', axis=1)
            
            # Remove duplicatas (mesma combinação From + To)
            issues_df = issues_df.drop_duplicates(subset=['From', 'To'], keep='first')
            
            # 🔧 CORREÇÃO: Verificação final antes de exportar
            if len(issues_df) == 0:
                self._create_success_sheet(writer, '✅ Nenhum redirect único encontrado após remoção de duplicatas!')
                return
            
            # 🎯 ORDEM DAS COLUNAS COMO SF
            column_order = [
                'Type', 'From', 'To', 'Status Code', 'Redirect To', 
                'Anchor Text', 'Redirect Type', 'Response Time', 'Issue', 'Priority'
            ]
            issues_df = issues_df[column_order]
            
            # Exporta para Excel
            issues_df.to_excel(writer, sheet_name=self.get_sheet_name(), index=False)
            
            # 📊 Log estatísticas como SF
            total_issues = len(issues_df)
            critical_issues = len(issues_df[issues_df['Priority'] == 'CRÍTICO'])
            redirect_301 = len(issues_df[issues_df['Status Code'] == '301'])
            redirect_302 = len(issues_df[issues_df['Status Code'] == '302'])
            
            self.logger.info(f"✅ {self.get_sheet_name()}: {total_issues} internal redirects")
            self.logger.info(f"   📊 301 Redirects: {redirect_301} | 302 Redirects: {redirect_302}")
            self.logger.info(f"   ⚠️  Critical Issues: {critical_issues}")
            
        except Exception as e:
            self.logger.error(f"Erro criando aba de links internos: {e}")
            self._create_error_sheet(writer, f'Erro: {str(e)}')
    
    def _format_issue_description(self, link: dict) -> str:
        """
        Formata descrição do problema como no Screaming Frog
        """
        redirect_type = str(link.get('tipo_problema', ''))
        status_code = str(link.get('codigo_redirect', ''))
        
        # Descrições como no SF
        descriptions = {
            'HTTP → HTTPS': f'{status_code} Redirect to HTTPS',
            'HTTPS → HTTP (Crítico)': f'{status_code} Redirect to HTTP (Security Risk)',
            'WWW Redirect': f'{status_code} WWW Redirect',
            'Trailing Slash': f'{status_code} Trailing Slash Redirect',
            'Capitalização': f'{status_code} Case Redirect',
            'Query String': f'{status_code} Query Parameter Redirect',
            'Mudança de Path': f'{status_code} Path Redirect',
            'Mudança de Domínio': f'{status_code} Domain Redirect',
            'Outro': f'{status_code} Redirect'
        }
        
        return descriptions.get(redirect_type, f'{status_code} Redirect')
    
    def _detect_redirects_hybrid_method(self, df: pd.DataFrame) -> list:
        """
        🔧 CORRIGIDO: Detecta redirects com tratamento seguro de arrays
        """
        problem_links = []
        
        # 🔧 CORREÇÃO: Verificação segura de DataFrame vazio
        if len(df) == 0:
            self.logger.info("DataFrame vazio, nenhum redirect para analisar")
            return problem_links
        
        self.logger.info(f"🔍 Analisando {len(df)} páginas para redirects...")
        
        # 🔧 MÉTODO 1: Parser modular novo (internal_redirects_details)
        method_1_count = self._extract_from_parser_modular(df, problem_links)
        
        # 🔧 MÉTODO 2: Mapeamento de redirects do crawl
        if method_1_count == 0:
            method_2_count = self._extract_from_redirect_mapping(df, problem_links)
            
        # 🔧 MÉTODO 3: Fallback - análise manual
        if len(problem_links) == 0:
            self._extract_from_fallback_analysis(df, problem_links)
        
        self.logger.info(f"🎯 Total: {len(problem_links)} internal redirects encontrados")
        return problem_links
    
    def _extract_from_parser_modular(self, df: pd.DataFrame, problem_links: list) -> int:
        """
        🔧 CORRIGIDO: Extrai dados do parser modular com verificações seguras
        """
        count = 0
        
        for _, row in df.iterrows():
            try:
                # 🎯 Busca dados do parser modular
                internal_redirects_details = row.get('internal_redirects_details', [])
                
                # 🔧 CORREÇÃO: Verificações seguras
                if internal_redirects_details is None:
                    continue
                    
                if not isinstance(internal_redirects_details, list):
                    continue
                    
                if len(internal_redirects_details) == 0:
                    continue
                
                for redirect_info in internal_redirects_details:
                    if isinstance(redirect_info, dict) and redirect_info.get('has_redirect', False):
                        entry = self._create_screaming_frog_entry(redirect_info)
                        if entry:  # Só adiciona se entry não é None/vazio
                            problem_links.append(entry)
                            count += 1
                            
            except Exception as e:
                self.logger.debug(f"Erro processando linha parser modular: {e}")
                continue
        
        if count > 0:
            self.logger.info(f"🔧 Método 1 (Parser Modular): {count} redirects encontrados")
        
        return count
    
    def _extract_from_redirect_mapping(self, df: pd.DataFrame, problem_links: list) -> int:
        """
        🔧 CORRIGIDO: Mapeamento com verificações seguras
        """
        count = 0
        
        # Constrói mapeamento de URLs que redirecionam
        url_to_final = {}
        
        for _, row in df.iterrows():
            try:
                url = str(row.get('url', '')).strip()
                final_url = str(row.get('final_url', '')).strip()
                status_code = row.get('status_code', 200)
                
                # 🔧 CORREÇÃO: Verificações seguras
                if not url or not final_url:
                    continue
                    
                if url == final_url:
                    continue
                
                url_to_final[url] = {
                    'final_url': final_url,
                    'status_code': status_code,
                    'redirect_type': self._classify_redirect_type(url, final_url),
                    'response_time': row.get('response_time', 0)
                }
                
            except Exception as e:
                self.logger.debug(f"Erro construindo mapeamento: {e}")
                continue
        
        # 🔧 CORREÇÃO: Verificação segura do mapeamento
        if len(url_to_final) == 0:
            return 0
        
        # Para cada página, verifica links internos
        for _, row in df.iterrows():
            try:
                pagina_origem = str(row.get('url', '')).strip()
                if not pagina_origem:
                    continue
                
                # Extrai links internos desta página
                internal_links = self._extract_internal_links_comprehensive(row, pagina_origem)
                
                # 🔧 CORREÇÃO: Verificação segura da lista
                if len(internal_links) == 0:
                    continue
                
                # Verifica se algum link interno está no mapeamento
                for link_url, anchor_text in internal_links:
                    if link_url in url_to_final:
                        redirect_info = url_to_final[link_url]
                        entry = self._create_screaming_frog_entry_from_mapping(
                            pagina_origem, link_url, anchor_text, redirect_info
                        )
                        if entry:  # Só adiciona se entry não é None/vazio
                            problem_links.append(entry)
                            count += 1
                            
            except Exception as e:
                self.logger.debug(f"Erro processando página: {e}")
                continue
        
        if count > 0:
            self.logger.info(f"🔧 Método 2 (Mapeamento): {count} redirects encontrados")
        
        return count
    
    def _extract_from_fallback_analysis(self, df: pd.DataFrame, problem_links: list):
        """
        🔧 CORRIGIDO: Análise fallback com verificações seguras
        """
        try:
            self.logger.info("🔧 Método 3 (Fallback): Executado como backup")
            # Implementação conservadora para evitar erros
            return 0
        except Exception as e:
            self.logger.debug(f"Erro no fallback: {e}")
            return 0
    
    def _create_screaming_frog_entry(self, redirect_info: dict) -> dict:
        """
        🔧 CORRIGIDO: Cria entrada com verificações seguras
        """
        try:
            if not isinstance(redirect_info, dict):
                return None
                
            # Verifica campos obrigatórios
            required_fields = ['pagina_origem', 'url_linkada', 'destino_final']
            for field in required_fields:
                if not redirect_info.get(field):
                    self.logger.debug(f"Campo obrigatório ausente: {field}")
                    return None
            
            return {
                'pagina_origem': str(redirect_info.get('pagina_origem', '')),
                'url_linkada': str(redirect_info.get('url_linkada', '')),
                'destino_final': str(redirect_info.get('destino_final', '')),
                'codigo_redirect': str(redirect_info.get('status_code', '')),
                'tipo_problema': self._format_redirect_type(str(redirect_info.get('redirect_type', ''))),
                'criticidade': self._determine_criticality(redirect_info),
                'anchor_text': str(redirect_info.get('anchor_text', '')),
                'response_time': f"{redirect_info.get('response_time', 0):.3f}s" if redirect_info.get('response_time', 0) > 0 else '',
            }
            
        except Exception as e:
            self.logger.debug(f"Erro criando entrada SF: {e}")
            return None
    
    def _create_screaming_frog_entry_from_mapping(self, pagina_origem: str, link_url: str, 
                                                anchor_text: str, redirect_info: dict) -> dict:
        """
        🔧 CORRIGIDO: Cria entrada do mapeamento com verificações
        """
        try:
            if not all([pagina_origem, link_url, redirect_info]):
                return None
                
            return {
                'pagina_origem': str(pagina_origem),
                'url_linkada': str(link_url),
                'destino_final': str(redirect_info.get('final_url', '')),
                'codigo_redirect': str(redirect_info.get('status_code', '')),
                'tipo_problema': self._format_redirect_type(str(redirect_info.get('redirect_type', ''))),
                'criticidade': self._determine_criticality_from_type(str(redirect_info.get('redirect_type', ''))),
                'anchor_text': str(anchor_text)[:100] if anchor_text else '',
                'response_time': f"{redirect_info.get('response_time', 0):.3f}s" if redirect_info.get('response_time', 0) > 0 else '',
            }
            
        except Exception as e:
            self.logger.debug(f"Erro criando entrada do mapeamento: {e}")
            return None
    
    def _extract_internal_links_comprehensive(self, row: pd.Series, base_url: str) -> list:
        """
        🔧 CORRIGIDO: Extração com verificações seguras
        """
        internal_links = []
        
        try:
            if not base_url:
                return internal_links
                
            base_domain = urlparse(base_url).netloc
            if not base_domain:
                return internal_links
            
            # FONTE 1: Parser modular (se disponível)
            internal_links_detailed = row.get('internal_links_detailed', [])
            
            if internal_links_detailed is not None and isinstance(internal_links_detailed, list) and len(internal_links_detailed) > 0:
                for link_info in internal_links_detailed:
                    if isinstance(link_info, dict):
                        url = str(link_info.get('url', '')).strip()
                        anchor = str(link_info.get('anchor', '')).strip()
                        if url and base_domain in url:
                            internal_links.append((url, anchor))
                            
                if len(internal_links) > 0:
                    return internal_links
            
            # FONTE 2: Busca básica em colunas
            for col_name in row.index:
                try:
                    value = row[col_name]
                    if pd.isna(value) or value == '':
                        continue
                        
                    value_str = str(value)
                    if base_domain in value_str:
                        # Procura por URLs que contenham o domínio
                        import re
                        url_pattern = rf'https?://[^\s<>"]+{re.escape(base_domain)}[^\s<>"]*'
                        found_urls = re.findall(url_pattern, value_str)
                        
                        for url in found_urls:
                            url_clean = url.strip('.,;!?')
                            if url_clean and url_clean not in [link[0] for link in internal_links]:
                                internal_links.append((url_clean, ''))
                                
                except Exception as e:
                    continue
            
        except Exception as e:
            self.logger.debug(f"Erro na extração: {e}")
        
        # Remove duplicatas
        seen = set()
        unique_links = []
        for url, anchor in internal_links:
            if url not in seen:
                seen.add(url)
                unique_links.append((url, anchor))
        
        return unique_links
    
    def _classify_redirect_type(self, original_url: str, final_url: str) -> str:
        """Classifica o tipo de redirecionamento"""
        try:
            parsed_orig = urlparse(str(original_url))
            parsed_final = urlparse(str(final_url))
            
            # HTTP -> HTTPS
            if parsed_orig.scheme == 'http' and parsed_final.scheme == 'https':
                return 'HTTP -> HTTPS'
            
            # HTTPS -> HTTP (crítico!)
            if parsed_orig.scheme == 'https' and parsed_final.scheme == 'http':
                return 'HTTPS -> HTTP'
            
            # WWW redirect
            if ('www.' in parsed_orig.netloc) != ('www.' in parsed_final.netloc):
                return 'WWW Redirect'
            
            # Trailing slash
            if (parsed_orig.netloc == parsed_final.netloc and 
                parsed_orig.path.rstrip('/') == parsed_final.path.rstrip('/') and
                parsed_orig.path != parsed_final.path):
                return 'Trailing Slash'
            
            # Path redirect
            if (parsed_orig.netloc == parsed_final.netloc and 
                parsed_orig.path != parsed_final.path):
                return 'Path Redirect'
            
            # Domain redirect
            if parsed_orig.netloc != parsed_final.netloc:
                return 'Domain Redirect'
            
            return 'Outro'
            
        except Exception:
            return 'Outro'
    
    def _format_redirect_type(self, redirect_type: str) -> str:
        """Formata tipo de redirect para display"""
        format_map = {
            'HTTP -> HTTPS': 'HTTP → HTTPS',
            'HTTPS -> HTTP': 'HTTPS → HTTP (Crítico)',
            'WWW Redirect': 'WWW Redirect',
            'Trailing Slash': 'Trailing Slash',
            'Capitalização': 'Capitalização',
            'Query String': 'Query String',
            'Path Redirect': 'Mudança de Path',
            'Domain Redirect': 'Mudança de Domínio',
            'Outro': 'Outro'
        }
        return format_map.get(str(redirect_type), str(redirect_type))
    
    def _determine_criticality(self, redirect_info: dict) -> str:
        """Determina criticidade do problema"""
        try:
            redirect_type = str(redirect_info.get('redirect_type', ''))
            return self._determine_criticality_from_type(redirect_type)
        except:
            return 'BAIXO'
    
    def _determine_criticality_from_type(self, redirect_type: str) -> str:
        """Determina criticidade baseada no tipo"""
        redirect_type_str = str(redirect_type)
        
        if 'HTTPS -> HTTP' in redirect_type_str:
            return 'CRÍTICO'
        elif redirect_type_str in ['Domain Redirect', 'Path Redirect']:
            return 'ALTO'
        elif redirect_type_str in ['HTTP -> HTTPS', 'WWW Redirect']:
            return 'MÉDIO'
        else:
            return 'BAIXO'